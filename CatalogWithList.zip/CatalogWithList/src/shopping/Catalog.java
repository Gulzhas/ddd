package shopping;

import java.util.ArrayList;

public class Catalog {
	
	ArrayList<String> items = new ArrayList<>();
	ArrayList<Double> prices = new ArrayList<>();
	ArrayList<Double> monthlyPayments = new ArrayList<>();

	/**
	 * This method adds all listed items to <items> arraylist
	 * that is already declared above
	 */
	public void loadItems() {
		String[] item = { "iPhone 6s", "iPhone 6s Plus", "iPhone X", "MacbookPro", "ThumbDrive", "Beats HeadPhones",
				"Mouse", "Charger", "iPad", "Dyson Vacuum", "TV", "Apple Watch" };
		for(int i=0;i<item.length;i++) {
			items.add(item[i]);
		}
		
		
		}
		
      /*	
		
		
	 */	
	
	/**
	 * This method adds all listed prices to <prices> arraylist
	 * that is already declared above
	 */
	public void loadPrices() {
		double[] price = { 449.0, 549.0, 1149.0, 1499.99, 39.99, 349.99, 79.99, 39.99, 429.0, 399.0, 2199.0, 559.0 };
	for(int i=0;i<price.length;i++) {
		prices.add(price[i]);
	}
		/*(449.0);
		(549.0);
		  1149.0
		  1499.99
		  39.99
		  349.99
		  79.99
		  39.99
		  429.0
		  399.0
		  2199.0
		  559.0
		 */
	}
	
	/**
	 * This method adds all listed monthly payments to <monthlyPayments> arraylist
	 * that is already declared above
	 */
	
	public void loadMonthlyPayments() {
		double[] monthlyPayment = { 18.71, 22.88, 56.16, 79.49, 2.68, 15.12, 8.98, 4.56, 18.31, 16.25, 89.49, 21.18 };
		for(int i=0; i<monthlyPayment.length;i++) {
			monthlyPayments.add(monthlyPayment[i]);
		}
		
		/*
		  18.71
		  22.88
		  56.16
          79.49
          2.68
          15.12
		  8.98
		  4.56
		  18.31
		  16.25
		  89.49
		  21.18
		  */
	}
	
	/**
	 * This method will load whole catalog data - <items>,<prices>,<monthlyPayments>
	 * Call loadItems(),loadPrices(),loadMonthlyPayments() that you created above
	 */
	public void loadWholeCatalog() {
		loadItems();
		loadPrices();
		loadMonthlyPayments();
	}

	/**
	 * Write a method that reads values from above ArrayLists and 
	 * returns a stringbuilder with all item details:
	 * return format:
	 * 		iPhone 6s-449.0-18.71
			iPhone 6s Plus-549.0-22.88
			..
	 * 
	 */
	
	public StringBuilder getWholeCatalog() {
		loadWholeCatalog();
		StringBuilder str=new StringBuilder();
		for(int i=0;i<items.size();i++) {
			str.append(items.get(i)+"-"+prices.get(i)+"-"+monthlyPayments.get(i)+"\n");
		}
		
		
		
		return str;
	}

	/**
	 * write a method that an item name and returns all details for it. If item
	 * is not in the list then returns null
	 *  ex: 
	 * getItemDetails("ThumbDrive") -->ThumbDrive-39.99-2.68 
	 * getItemDetails("Charger") --> Charger-39.99-4.56
	 * getItemDetails("Potato") --> null
	 * 
	 * @param item
	 * @return
	 */

	public String getItemDetails(String item) {
		loadWholeCatalog();
		String details="";
		for(int i=0;i<items.size();i++) {
			if(items.get(i).equals(item)) {
				return details+=items.get(i)+"-"+prices.get(i)+"-"+monthlyPayments.get(i);
				
			}
		}
		
		
				
		return details=null;
	}

	/**
	 * write a method that accepts a price and returns a ArrayList<String> with
	 * items with all detail that have less than or equal monthly payments
	 * 
	 * getItemsLessThanAMonthlyPrice(5.99) --> ThumbDrive-39.99-2.68
	 * 										  Charger-39.99-4.56 
	 * getItemsLessThanAMonthlyPrice(1.99) --> ""
	 * 
	 * @param double price
	 * @return ArrayList<String>
	 */

	public ArrayList<String> getItemsLessThanAMonthlyPrice(double price) {
		loadWholeCatalog();
		
		
		ArrayList<String> lessMonthlyPay = new ArrayList<>();
		StringBuilder con=new StringBuilder();
				for(int i=0; i<monthlyPayments.size();i++) {
					if(monthlyPayments.get(i)==price || monthlyPayments.get(i)<price ) {
						con.append(items.get(i)+"-"+prices.get(i)+"-"+monthlyPayments.get(i)+"\n");
					}
				}
				String st=con.toString();
				String[] stArr=st.split("\n");
				for(String item:stArr) {
					lessMonthlyPay.add(item);
				}
		return lessMonthlyPay;
	}
	
	/**
	 * Method accepts a item name and updates total Price and monthly payments
	 * for that item in <items>,<prices>,<monthlyPayments> arrayLists
	 * 
	 * @param item name
	 * @param newPrice
	 */
	
	public void updatePrice(String item, double newPrice) {
		loadWholeCatalog();
		double UpdatedMonthly=newPrice/12;
		for(int i=0;i<items.size();i++) {
			if(items.get(i).equals(item)) {
				prices.set(i, newPrice);
				monthlyPayments.set(i, UpdatedMonthly);
			}
		}
		
	
	}
	
	/**
	 * Method looks for an item in the catalog and removes
	 * all details for that item including item name, price, monthlypayments
	 * 
	 * 
	 * @param item
	 */
	
	public void deleteItemFromCatalog(String item) {
		loadWholeCatalog();
		for(int i=0; i<items.size();i++) {
			if(items.get(i).equals(item)) {
				items.remove(i);
				prices.remove(i);
				monthlyPayments.remove(i);
			}
		}
		
	
	}
	

}
